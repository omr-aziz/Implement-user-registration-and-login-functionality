﻿using Xunit;
using BookifyMembership.Controllers;
using BookifyMembership.Models;
using Microsoft.AspNetCore.Mvc;

namespace BookifyMembership.Tests
{
    public class MembersControllerTests
    {
        private readonly MembersController _controller;

        public MembersControllerTests()
        {
            _controller = new MembersController();
        }

        [Fact]
        public void Register_ShouldReturnCreatedResult_WhenUserIsValid()
        {
            // Arrange
            var newUser = new User
            {
                Username = "testuser",
                Email = "testuser@example.com",
                PasswordHash = "Test@123"
            };

            // Act
            var result = _controller.Register(newUser) as CreatedAtActionResult;

            // Assert
            Assert.NotNull(result);
            Assert.Equal(201, result.StatusCode);
        }

        [Fact]
        public void Register_ShouldReturnBadRequest_WhenUsernameOrEmailExists()
        {
            // Arrange
            var existingUser = new User
            {
                Username = "existinguser",
                Email = "existinguser@example.com",
                PasswordHash = "Password123"
            };
            _controller.Register(existingUser);

            var duplicateUser = new User
            {
                Username = "existinguser",
                Email = "newemail@example.com",
                PasswordHash = "Password123"
            };

            // Act
            var result = _controller.Register(duplicateUser) as BadRequestObjectResult;

            // Assert
            Assert.NotNull(result);
            Assert.Equal(400, result.StatusCode);
        }

        [Fact]
        public void Login_ShouldReturnOkResult_WhenCredentialsAreValid()
        {
            // Arrange
            var newUser = new User
            {
                Username = "loginuser",
                Email = "loginuser@example.com",
                PasswordHash = "Password@123"
            };
            _controller.Register(newUser);

            var loginRequest = new LoginRequest
            {
                UsernameOrEmail = "loginuser",
                Password = "Password@123"
            };

            // Act
            var result = _controller.Login(loginRequest) as OkObjectResult;

            // Assert
            Assert.NotNull(result);
            Assert.Equal(200, result.StatusCode);
        }

        [Fact]
        public void Login_ShouldReturnUnauthorizedResult_WhenCredentialsAreInvalid()
        {
            // Arrange
            var loginRequest = new LoginRequest
            {
                UsernameOrEmail = "nonexistentuser",
                Password = "WrongPassword"
            };

            // Act
            var result = _controller.Login(loginRequest) as UnauthorizedObjectResult;

            // Assert
            Assert.NotNull(result);
            Assert.Equal(401, result.StatusCode);
        }
    }
}
