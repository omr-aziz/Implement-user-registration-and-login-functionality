﻿using BookifyMembership.Models;
using System.Collections.Generic;
using System.Linq;

namespace BookifyMembership.Repositories
{
    public class UserRepository
    {
        private static List<User> _users = new List<User>();
        private static int _nextId = 1;

        public User AddUser(User user)
        {
            user.UserId = _nextId++;
            _users.Add(user);
            return user;
        }

        public User GetUserByUsernameOrEmail(string identifier)
        {
            return _users.FirstOrDefault(u => u.Username == identifier || u.Email == identifier);
        }

        public List<User> GetAllUsers()
        {
            return _users;
        }
    }
}
