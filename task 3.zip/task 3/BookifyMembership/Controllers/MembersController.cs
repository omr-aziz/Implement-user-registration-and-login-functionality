﻿using BookifyMembership.Models;
using BookifyMembership.Repositories;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;

namespace BookifyMembership.Controllers
{
    [Route("api/members")]
    [ApiController]
    public class MembersController : ControllerBase
    {
        private readonly UserRepository _repository = new UserRepository();
        private readonly PasswordHasher<User> _passwordHasher = new PasswordHasher<User>();

        [HttpPost("register")]
        public IActionResult Register([FromBody] User user)
        {
            if (_repository.GetUserByUsernameOrEmail(user.Username) != null ||
                _repository.GetUserByUsernameOrEmail(user.Email) != null)
            {
                return BadRequest(new { message = "Username or Email already exists." });
            }

            user.PasswordHash = _passwordHasher.HashPassword(user, user.PasswordHash);
            var newUser = _repository.AddUser(user);
            return CreatedAtAction(nameof(Register), new { id = newUser.UserId }, newUser);
        }

        [HttpPost("login")]
        public IActionResult Login([FromBody] LoginRequest loginRequest)
        {
            var user = _repository.GetUserByUsernameOrEmail(loginRequest.UsernameOrEmail);

            if (user == null)
            {
                return Unauthorized(new { message = "Invalid username or email." });
            }

            var result = _passwordHasher.VerifyHashedPassword(user, user.PasswordHash, loginRequest.Password);

            if (result == PasswordVerificationResult.Failed)
            {
                return Unauthorized(new { message = "Invalid password." });
            }

            return Ok(new { message = "Login successful", membershipTier = user.MembershipTier });
        }

        [HttpPost("{userId}/upgrade")]
        public IActionResult UpgradeMembership(int userId)
        {
            // البحث عن المستخدم باستخدام معرفه
            var user = _repository.GetAllUsers().FirstOrDefault(u => u.UserId == userId);

            if (user == null)
            {
                return NotFound(new { message = "User not found." });
            }

            // ترقية مستوى العضوية
            if (user.MembershipTier == "Premium")
            {
                return BadRequest(new { message = "User is already a Premium member." });
            }

            user.MembershipTier = "Premium";
            return Ok(new { message = "Membership upgraded to Premium.", membershipTier = user.MembershipTier });
        }

    }

    public class LoginRequest
    {
        public string UsernameOrEmail { get; set; }
        public string Password { get; set; }
    }
}
